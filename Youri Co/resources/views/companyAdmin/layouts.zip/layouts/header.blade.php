<style>
    .profile-card {
        position: absolute;
        top: 40px;
        right: 0;
        display: none;
        width: 200px;
        z-index: 1000;
    }
    .profile-pic:hover + .profile-card, .profile-card:hover {
        display: block;
    }
    .profile-pic {
        cursor: pointer;
    }
    .nav-item {
        position: relative;
    }
</style>
    
<header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav mr-auto">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler d-block d-sm-none waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <li class="nav-item"> <a class="nav-link sidebartoggler d-none d-lg-block d-md-block waves-effect waves-dark" href="javascript:void(0)"><i class="icon-menu"></i></a> </li>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class="nav-item">
                            <form class="app-search d-none d-md-block d-lg-block">
                                <input type="text" class="form-control" placeholder="Search & enter">
                            </form>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                     <ul class="navbar-nav my-lg-0">
                        <!-- First Profile -->
                        <li class="nav-item dropdown u-pro">
                            <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" href="#" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">
                                <img src="/uploads/{{ Auth::user()->logo_img }}" alt="user" class="rounded-circle" width="30" height="30">
                                <span class="hidden-md-down"><i class="fa fa-angle-down"></i></span>
                            </a>
                            <div class="card profile-card dropdown-menu-right animated flipInY" aria-labelledby="navbarDropdown1">
                                <div class="card-body">
                                    <h5 class="card-title">{{ Auth::user()->name }}</h5>
                                    <a href="{{ route('profile', Auth::user()->id) }}" class="dropdown-item"><i class="ti-user"></i> My Profile</a>
                                    <form method="POST" action="{{ route('logout') }}">
                                        @csrf
                                        <x-dropdown-link :href="route('logout')"
                                                onclick="event.preventDefault();
                                                            this.closest('form').submit();">
                                            Log Out
                                        </x-dropdown-link>
                                    </form>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
            <!-- jQuery -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
            <!-- Bootstrap JS -->
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        </header>